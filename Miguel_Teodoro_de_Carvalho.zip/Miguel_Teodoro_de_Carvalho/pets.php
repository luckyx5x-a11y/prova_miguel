<?php
include "proteger.php";
include "config.php";
$raca = "";
$nome = "";
$especie = "";
$data_nascimento = "";
$tutor = "";
$sql = 'SELECT id, nome FROM tutores';

$tutores =  $conexao->query($sql);
if ($_SERVER['REQUEST_METHOD'] == "POST") {

    $raca = trim($_POST["raca"] ?? '');
    $nome = trim($_POST["nome"] ?? '');
    $especie = trim($_POST["especie"] ?? '');
    $data_nascimento = $_POST["data_nascimento"] ?? '';
    $tutor = $_POST['tutor_id'] ?? '';

    if ($nome == '' || $raca == '' || $especie == '' || $data_nascimento == '') {
        $erro = 'Preencha todos os campos';
    } else {
        $sql = 'INSERT INTO pets (nome, raca, especie, data_nascimento, tutor_id) VALUES(?, ?, ?, ?, ?)';
        $stmt = $conexao->prepare($sql);
        $stmt->bind_param('ssssi', $nome, $raca, $especie, $data_nascimento, $tutor);
        $stmt->execute();
    }
}

$sql = "SELECT
p.*,
t.nome AS tutor
FROM pets p
INNER JOIN tutores t
ON t.id = p.tutor_id
ORDER BY p.nome;";

$petsinfo = $conexao->query($sql)
?>



<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <?php include 'voltar.php' ?>
    <h1>Insirir o Pet</h1>
    <h2>inserir tutor</h2>
    <form action="" method="post">
        <label>Nome:</label>
        <input type="text" name="nome" value="<?= htmlspecialchars($nome) ?>">
        <br><br>
        <label>Raca:</label>
        <input type="text" name="raca" value="<?= htmlspecialchars($raca) ?>">
        <br><br>
        <label>Especie:</label>
        <input type="number" name="especie" value="<?= htmlspecialchars($especie) ?>">
        <br><br>
        <label>data de nascimento:</label>
        <input type="date" name="data_nascimento" value="<?= htmlspecialchars($data_nascimento) ?>">
        <br><br>
        <select name="tutor_id">
            <option value="selecione o tutor">Selecione o tutor</option>
            <?php while ($tutor = $tutores->fetch_assoc()): ?>
                <option value="<?= $tutor['id'] ?>"><?= $tutor['nome'] ?></option>
            <?php endwhile ?>
        </select>
        <button type="submit">Salvar</button>
    </form>

    <table border="1" cellpadding="5">
        <tr>
            <th>id</th>
            <th>nome</th>
            <th>raca</th>
            <th>especie</th>
            <th>tutor</th>
            <th>data de nascimento <th>
        </tr>
        <?php if($petsinfo): ?>
        <?php while ($pets = $petsinfo->fetch_assoc()): ?>
            <tr>
                <td><?= $pets['id'] ?></td>
                <td><?= $pets['nome'] ?></td>
                <td><?= $pets['raca'] ?></td>
                <td><?= $pets['especie'] ?></td>
                <td><?= $pets['data_nascimento'] ?></td>
        <?php endwhile ?>
        <?php endif; ?>
        

    </table>

</body>

</html>