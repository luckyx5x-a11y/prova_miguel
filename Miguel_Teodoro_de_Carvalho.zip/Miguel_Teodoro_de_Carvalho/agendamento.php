<?php
require 'config.php';
require 'proteger.php';

$sql = "SELECT
a.id,
a.data_hora,
a.motivo,
a.observacoes,
p.nome AS pet_nome,
p.especie AS pet_especie,
p.raca AS pet_raca,
t.nome AS tutor_nome,
t.telefone AS tutor_tel,
t.email AS tutor_email,
t.cpf_criptografado
FROM agendamentos a
INNER JOIN pets p
ON p.id = a.pet_id
INNER JOIN tutores t
ON t.id = p.tutor_id
ORDER BY a.data_hora ASC;";


$agendamentosInfo = $conexao->query($sql);






?>


<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agendamento</title>
</head>
<body>
    <?php include 'voltar.php' ?>
    <h1>Agendamentos</h1>

       <table border="1" cellpadding="5">
        <tr>
            <th>id</th>
            <th>motivo</th>
            <th>descricao</th>
            <th>especie</th>

            <th>Nome do pet</th>
            <th>Raça do pet</th>
            <th>Especie do Pet</th>

            <th>Nome do tutor</th>
            <th>Telefone do tutor</th>
            <th>Email do tutor</th>
            <th></th>
            
        </tr>
        <?php if($agendamentosInfo): ?>
        <?php while ($ag = $agendamentosInfo->fetch_assoc()): ?>
            <tr>
                <td><?= $ag['id'] ?></td>
                <td><?= $ag['motivo'] ?></td>
                <td><?= $ag['observacoes'] ?></td>
                <td><?= $ag['pet_especie'] ?></td>

                <td><?= $ag['pet_nome'] ?></td>
                <td><?= $ag['pet_raca'] ?></td>
                <td><?= $ag['pet_especie'] ?></td>

                <td><?= $ag['tutor_nome'] ?></td>
                <td><?= $ag['tutor_tel'] ?></td>
                <td><?= $ag['tutor_email'] ?></td>
        <?php endwhile ?>
        <?php endif; ?>
        

    </table>
</body>
</html>
