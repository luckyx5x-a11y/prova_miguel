<?php
session_start();

$tempo_maximo = 1800;

if(!isset($_SESSION['usuario_id'])){
    header("Location: login.php");
    exit;
}

if(
    isset($_SESSION["ultima_atividade"]) && time() - $_SESSION['ultima_atividade'] > $tempo_maximo

){
    session_start();
session_destroy();

header("Location: login.php");
exit;
}

$_SESSION["ultima_atividade"] = time();
?>