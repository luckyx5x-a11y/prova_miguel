create database saep_db;

use saep_db;

create table usuarios (
id int primary key auto_increment,
nome varchar(100),
login varchar(60),
senha_hash char (64)
);

create table tutores (
id int auto_increment primary key,
nome varchar(120),
cpf_criptografado text,
telefone varchar(20),
email varchar(120)
);

create table pets(
id int primary key auto_increment,
tutor_id int,
nome varchar(100),
raca varchar(100),
especie varchar(100),
data_nascimento date,
foreign key(tutor_id) references tutores(id)
);

create table agendamentos(
id int primary key auto_increment,
pet_id int not null,
data_hora datetime not null,
motivo varchar(255),
observacoes TEXT,
foreign key (pet_id) references pets(id)
);

INSERT INTO `saep_db`.`tutores` (`id`, `nome`, `cpf_criptografado`, `email`, `telefone`) VALUES ('1', 'joao', '12222222', 'miguel@gmail.com', '122222');
INSERT INTO `saep_db`.`tutores` (`id`, `nome`, `cpf_criptografado`, `email`, `telefone`) VALUES ('2', 'maria', '12222222', 'miguel@gmail.com', '122222');
INSERT INTO `saep_db`.`tutores` (`id`, `nome`, `cpf_criptografado`, `email`, `telefone`) VALUES ('3', 'jose', '12222222', 'miguel@gmail.com', '122222');


INSERT INTO `saep_db`.`pets` (`id`, `tutor_id`, `nome`, `raca`, `especie`, `data_nascimento`) VALUES ('1', '2', 'chiu', 'dog', 'dog', '2008-01-01');
INSERT INTO `saep_db`.`pets` (`id`, `tutor_id`, `nome`, `raca`, `especie`, `data_nascimento`) VALUES ('2', '1', 'chiu2', 'pood', 'podd', '2008-01-01');
INSERT INTO `saep_db`.`pets` (`id`, `tutor_id`, `nome`, `raca`, `especie`, `data_nascimento`) VALUES ('3', '3', 'asd', 'asd', 'aas', '2008-01-01');

INSERT INTO `saep_db`.`agendamentos` (`id`, `pet_id`, `data_hora`, `motivo`, `observacoes`) VALUES ('1', '2', '2026-10-02 14:30:00', 'assd', 'asda');
INSERT INTO `saep_db`.`agendamentos` (`id`, `pet_id`, `data_hora`, `motivo`, `observacoes`) VALUES ('2', '2', '2026-10-02 14:30:00', 'assd', 'asda');
INSERT INTO `saep_db`.`agendamentos` (`id`, `pet_id`, `data_hora`, `motivo`, `observacoes`) VALUES ('3', '1', '2026-10-02 14:30:00', 'assd', 'asda');

INSERT INTO `saep_db`.`usuarios` (`id`, `nome`, `login`) VALUES ('1', 'miguel', 'miguel@gmail.com');
INSERT INTO `saep_db`.`usuarios` (`id`, `nome`, `login`) VALUES ('2', 'maria', 'maria@gmail.com');
INSERT INTO `saep_db`.`usuarios` (`id`, `nome`, `login`) VALUES ('3', 'jose', 'jose@gmail.com');

