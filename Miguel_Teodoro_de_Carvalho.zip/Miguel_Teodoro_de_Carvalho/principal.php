<?php
include 'proteger.php'



?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>principal</title>
</head>

<body>

    <p>Usário Logado: <?php echo $_SESSION['usuario_nome'] ?></p>
    <a href="tutores.php">tutores</a>
    <br><br>
    <a href="pets.php">pets</a>
    <br><br>
    <a href="agendamento.php">agendamentos</a>
    <br><br>
    <a href="logout.php">logout</a>
</body>

</html>