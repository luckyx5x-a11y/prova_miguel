<?php


$nome = "";
$email = "";
$telefone = "";
$cpf = "";
$erro = "";

include "config.php";
if ($_SERVER['REQUEST_METHOD'] == "POST") {

    $email = trim($_POST["email"] ?? '');
    $nome = trim($_POST["nome"] ?? '');
    $telefone = trim($_POST["telefone"] ?? '');
    $cpf = $_POST["cpf"] ?? '';
    $cpfCriptografado = password_hash($cpf, PASSWORD_DEFAULT);


    if ($nome == '' || $email == '' || $telefone == '' || $cpf == '') {
        $erro = 'Preencha todos os campos';
    } else {
        $sql = 'INSERT INTO tutores (nome, email, telefone, cpf_criptografado) VALUES(?, ?, ?, ?)';
        $stmt = $conexao->prepare($sql);
        $stmt->bind_param('ssss', $nome, $email, $telefone, $cpfCriptografado);
        $stmt->execute();
    }
}

//Excluir

if (isset($_GET['excluir'])) {
    $idExcluir = intval($_GET['excluir']);
    $sql = "SELECT COUNT(*) AS total FROM pets where tutor_id = ?";
    $stmt = $conexao->prepare($sql);
    $stmt->bind_param('i', $idExcluir);
    $stmt->execute();
    $total = $stmt->get_result()->fetch_assoc()['total'];

    if ($total > 0) {
        $erro = "Erro ao excluir, o sistema ja possui pets cadastrados nesse usuario";
    } else {
        $sql = 'DELETE FROM tutores where id = ?';
        $stmt = $conexao->prepare($sql);
        $stmt->bind_param("i", $idExcluir);
        $stmt->execute();
        $mensagem = 'Tutor Excluido';
    }
}

$busca = trim($_GET['busca'] ?? '');

if ($busca != "") {
    $sql = 'SELECT *
FROM tutores
WHERE nome LIKE ?
OR telefone LIKE ?
OR email LIKE ?
ORDER BY nome;';

    $stmt = $conexao->prepare($sql);
    $termo = "%" . $busca . "%";
    $stmt->bind_param("sss", $busca, $busca, $busca);
    $stmt->execute();
    $resultado = $stmt->get_result();
} else {
    $resultado = $conexao->query("SELECT * FROM tutores");
}

?>


<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>tutores</title>
</head>

<body>
    <h1>Pagina principal</h1>
    <?php include 'voltar.php' ?>
    <h2>inserir tutor</h2>
    <form action="" method="post">
        <label>Nome:</label>
        <input type="text" name="nome" value="<?= htmlspecialchars($nome) ?>">
        <br><br>
        <label>Email:</label>
        <input type="text" name="email" value="<?= htmlspecialchars($email) ?>">
        <br><br>
        <label>CPF:</label>
        <input type="number" name="cpf" value="<?= htmlspecialchars($cpf) ?>">
        <br><br>
        <label>Telefone:</label>
        <input type="number" name="telefone" value="<?= htmlspecialchars($telefone) ?>">
        <br><br>
        <button type="submit">Salvar</button>
    </form>

    <?php if ($erro != ''): ?>

        <h1><?= htmlspecialchars($erro) ?></h1>


    <?php endif ?>
    <h1>tutores</h1>

    <form method="get">
        <input type="text" name="busca" value="<?= htmlspecialchars($busca) ?>">
        <button type="submit">Buscar</button>
        <a href="tutores.php">Limpar</a>
    </form>

    <table border="1" cellpadding="5">
        <tr>
            <th>id</th>
            <th>nome</th>
            <th>telefone</th>
            <th>cpf</th>
            <th>Acoes</th>
        </tr>

        <?php while ($tutores = $resultado->fetch_assoc()): ?>
            <tr>
                <td><?= $tutores['id'] ?></td>
                <td><?= $tutores['nome'] ?></td>
                <td><?= $tutores['telefone'] ?></td>
                <td><?= $tutores['cpf_criptografado'] ?></td>
                <td><a href="tutores.php?excluir=<?= $tutores['id'] ?>">Excluir</a>
                <?php endwhile ?>

    </table>

</body>

</html>