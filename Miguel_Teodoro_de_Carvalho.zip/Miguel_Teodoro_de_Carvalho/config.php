<?php
$conexao = new mysqli("localhost", "root", "", "saep_db", "3308");

if($conexao->connect_error){
    die('Erro na conexão.');
}

$conexao->set_charset('utf8mb4');




?>