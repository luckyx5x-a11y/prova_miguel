<?php
include 'config.php';

session_start();


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $login = trim($_POST["login"] ?? '');
    $senha =  $_POST["senha"] ?? "";
    $erro = "";

    $sql = "SELECT id, nome, senha_hash FROM usuarios WHERE login = ?";
    $stmt = $conexao->prepare($sql);
    $stmt->bind_param('s', $login);
    $stmt->execute();

    $resultado = $stmt->get_result();

    if ($usuario = $resultado->fetch_assoc()) {
        $_SESSION["usuario_id"] = $usuario["id"];
        $_SESSION["usuario_nome"] = $usuario["nome"];
        $_SESSION["ultima"] = time();

        header("Location: principal.php");
    } else {
        $erro = "Usuario ou senha invalidos";
    }
}


?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login</title>
</head>
<body>

<h1>login</h1>


<?php if($erro != ''): ?>

<h1><?= htmlspecialchars($erro) ?></h1>


<?php endif ?>

<form method="post">

<label for="">email</label>

<input type="text" name="login" id="">

<label for="">senha</label>

<input type="text" name="senha" id="">

<button type="submit"></button>

</form>
    
</body>
</html>
